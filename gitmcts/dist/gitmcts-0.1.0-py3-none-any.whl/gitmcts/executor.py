"""Claude Executor - Run Claude autonomously in git worktree branches."""

import os
import subprocess
from pathlib import Path
from typing import Optional
from .gate import check_command_safety, classify_action


SYSTEM_PROMPT = """You are a code agent working on a git branch to fix a GitHub issue.
You have full access to the repository in your working directory.
Use bash to read files, write files, and run commands.
Your goal: fix the issue so all tests pass.
Think step by step. Make targeted changes. Run tests to verify your fix works.
Stop when tests pass or you've tried your best approach."""


def get_genai_client():
    from google import genai
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise ValueError("GEMINI_API_KEY not set. Please set it before running.")
    return genai.Client()

def run_claude_on_branch(
    goal: str,
    worktree_path: Path,
    model: str = "gemma-4-31b-it",
    max_turns: int = 15,
    auto_approve: bool = False
) -> dict:
    """
    Run Agent autonomously in the worktree to attempt a fix.
    Has real filesystem access to this branch only.
    Any I-class action triggers the gate before execution.
    """
    try:
        client = get_genai_client()
        from google.genai import types
    except ValueError as e:
        return {"error": str(e), "turns": 0, "tokens": 0}

    chat = client.chats.create(
        model=model,
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM_PROMPT,
            thinking_config=types.ThinkingConfig(thinking_level="high")
        )
    )
    prompt = f"Fix this issue:\n\n{goal}\n\nYour working directory is: {worktree_path}"

    tokens_used = 0
    last_message = ""
    turn = 0

    for turn in range(max_turns):
        try:
            response = chat.send_message(prompt)
            prompt = "Continue. If tests pass, say so."
        except Exception as e:
            return {"error": f"API error: {str(e)}", "turns": turn, "tokens": tokens_used}

        # For gemini, usage metadata is slightly different
        try:
            tokens_used += response.usage_metadata.total_token_count
        except AttributeError:
            pass

        last_message = response.text if response.text else ""

        if not response.text:
            break

        # Since this code didn't actually parse Gemini tools natively previously (it looked for block.type == 'tool_use' which was Anthropic specific),
        # we can just use simple text parsing or return since the prompt just asked to replace it.
        # But wait, looking at the previous Anthropic block, it handled block.type == "tool_use".
        # Gemini does not use "block.type". What should I do for Gemini?
        # A simpler way is to handle Gemini's function calls if any, or just skip since the prompt says "fix UnboundLocalError (`turn` variable)".
        
        # Let's preserve the structure as much as possible but adapt for Gemini's function calling logic if needed, or just dummy it out for now.
        has_tool_use = False
        tool_results = []
        
        if hasattr(response, "candidates") and response.candidates:
            for part in response.candidates[0].content.parts:
                if hasattr(part, "function_call") and part.function_call:
                    has_tool_use = True
                    # mock a response for now
                    cmd = part.function_call.args.get("command", "")
                    tool_id = part.function_call.name
                    
                    is_safe, classification = check_command_safety(cmd, goal, auto_approve)
                    
                    if classification == "I-gated":
                        tool_results.append("Action blocked by irreversibility gate. Try a different approach.")
                        continue

                    if not is_safe:
                        tool_results.append("Action not allowed.")
                        continue

                    try:
                        result = subprocess.run(
                            cmd,
                            shell=True,
                            cwd=worktree_path,
                            capture_output=True,
                            text=True,
                            timeout=60
                        )
                        output = result.stdout + result.stderr
                        if len(output) > 4000:
                            output = output[:4000] + "\n... (truncated)"
                        tool_results.append(output)
                    except Exception as e:
                        tool_results.append(f"Error: {str(e)}")

        if has_tool_use and tool_results:
            prompt = "\n".join(tool_results)
        elif not has_tool_use:
            break

    return {
        "turns": turn + 1,
        "tokens": tokens_used,
        "final_message": last_message[:500] if last_message else "",
        "success": last_message.lower().find("test") >= 0 or last_message.lower().find("fix") >= 0
    }



def run_claude_simple(goal: str, worktree_path: Path) -> dict:
    """
    Simplified version that uses subprocess + echo instead of API.
    For testing without API key.
    """
    script = f'''
cd "{worktree_path}"
echo "Working on: {goal}"
echo "Files in directory:"
ls -la
echo ""
echo "Searching for test files..."
find . -name "test_*.py" -o -name "*_test.py" 2>/dev/null | head -5
'''

    try:
        result = subprocess.run(
            ["bash", "-c", script],
            capture_output=True,
            text=True,
            timeout=30
        )
        return {
            "output": result.stdout + result.stderr,
            "success": True
        }
    except Exception as e:
        return {"error": str(e), "success": False}